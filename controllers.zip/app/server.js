const http = require("http");
const mongoose = require("mongoose");
const app = require("../app");
const socketIo = require("socket.io");

const { PORT = 1594, DB_HOST } = process.env;

mongoose
    .connect(DB_HOST)
    .then(() => {
        const server = http.createServer(app);
        const io = socketIo(server);

        // Здесь можно добавить обработчики событий для socket.io
        io.on("connection", (socket) => {
            console.log("New client connected");

            socket.on("disconnect", () => {
                console.log("Client disconnected");
            });

            // Добавьте другие обработчики событий, если необходимо
        });

        server.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    })
    .catch((error) => {
        console.log(error.message);
        process.exit(1);
    });
