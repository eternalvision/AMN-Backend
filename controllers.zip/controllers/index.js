const auth = require("./auth");
// const staff = require("./staff");

module.exports = {
    auth,
    // staff,
};
